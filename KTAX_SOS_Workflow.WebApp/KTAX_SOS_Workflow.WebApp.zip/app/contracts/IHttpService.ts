﻿/// <reference path="../configs/_all.ts" />

module KTAX_SOS_Workflow {
    export interface IHttpService extends ng.IHttpService {
        
    }
} 