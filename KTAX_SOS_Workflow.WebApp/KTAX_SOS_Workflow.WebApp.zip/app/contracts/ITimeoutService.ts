/// <reference path="../configs/_all.ts" />

module KTAX_SOS_Workflow {
    export interface ITimeoutService extends angular.ITimeoutService {
    }
}