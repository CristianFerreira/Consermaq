/// <reference path="../configs/_all.ts" />

module KTAX_SOS_Workflow {
    export interface IModalService extends angular.ui.bootstrap.IModalService {
    }
}