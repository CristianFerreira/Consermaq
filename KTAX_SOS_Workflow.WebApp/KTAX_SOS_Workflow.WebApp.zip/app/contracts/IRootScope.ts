/// <reference path="../configs/_all.ts" />

module KTAX_SOS_Workflow {
    export interface IRootScope extends ng.IRootScopeService {
        header: any;
        token: string;
        sistemaContexo: SistemaContexto;
    }
}