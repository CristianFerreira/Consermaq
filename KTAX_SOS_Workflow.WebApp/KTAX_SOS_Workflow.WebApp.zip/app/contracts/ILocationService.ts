﻿/// <reference path="../configs/_all.ts" />

module KTAX_SOS_Workflow {
    export interface ILocationService extends ng.ILocationService {
        
    }
} 