﻿/// <reference path="../configs/_all.ts" />

module KTAX_SOS_Workflow {
    export interface IRouteParamsService extends angular.route.IRouteParamsService {
        id: number;
    }
} 