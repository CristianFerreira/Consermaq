
/// <reference path="../configs/_all.ts" />


module KTAX_SOS_Workflow {

    export class WorkflowService extends AppServiceBase implements IAppService{

        public getById(id: number): any {
            return super.getByIdFromUrl(appConfig.serviceUrls().workflow.listAll, id);
        }

        public listAll(): any {
            return super.listAllFromUrl(appConfig.serviceUrls().workflow.listAll);
        }

        public executaControleAndamentoTarefa(workflow: Workflow): any{

            var params = "?idControleAndamentoTarefa=" + workflow.idControleAndamentoTarefa; 
                params += "&idProcesso=" + workflow.idProcesso;

            return super.getFromUrl(appConfig.serviceUrls().workflow.executaControleAndamentoTarefa, params);
        }
    }

    angular.module(appConfig.appName).service("WorkflowService", WorkflowService);
}