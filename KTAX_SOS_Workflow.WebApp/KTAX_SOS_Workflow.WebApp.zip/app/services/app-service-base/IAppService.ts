﻿
/// <reference path="../../configs/_all.ts" />


module KTAX_SOS_Workflow {

    export interface  IAppService {
        
        getById(id: number): any;
        listAll(): any;
        handlerResponded(response: any, params?: any): any;
    }
}