
/// <reference path="../configs/_all.ts" />


module KTAX_SOS_Workflow {

    export class SosTarefarealizadoService extends AppServiceBase implements IAppService{

        public getById(id: number): any {
            return super.getByIdFromUrl(appConfig.serviceUrls().workflow.listAll, id);
        }

        public listAll(): any {
            return super.listAllFromUrl(appConfig.serviceUrls().workflow.listAll);
        }

        public lancamentoDeHoras(idTarefa: number, idSprintProjeto: number, horas: string): any{

            var params = "?idTarefa=" + idTarefa; 
                params += "&idSprintProjeto=" + idSprintProjeto;
                params += "&horas=" + horas;

            return super.getFromUrl(appConfig.serviceUrls().sosTarefarealizado.lancamentoDeHoras, params);
        }
    }

    angular.module(appConfig.appName).service("SosTarefarealizadoService", SosTarefarealizadoService);
}