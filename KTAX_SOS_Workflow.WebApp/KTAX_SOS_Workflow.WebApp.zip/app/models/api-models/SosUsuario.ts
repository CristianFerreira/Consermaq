﻿

/// <reference path="../../configs/_all.ts" />
module KTAX_SOS_Workflow {
    export class SosUsuario {
        public idUsuario: number;
        public strUsuario: string;
        public wdSenha: string;
        public idTipoUsuario: number;
        public strEmail: string;
        public strFoneCelular: string;
        public strFoneRamal: string;
        public idSetor: number;
        public chStatus: string;
        public strNomeUsuario: string;
        public idUsuarioKtax: number;
        public staprimeironivel: boolean;
        public staResponsavelSprint: boolean;
        public staResponsavelProjetos: boolean;
        public idPerfil: number;
        public staIniciaExecucaoWorkFlow: boolean;
        public staguttarefanew: boolean;
        public staExecutor: string;
        public staSelecionaProjeto: string;
        public senha: string;

        constructor() {

        }
    }
} 