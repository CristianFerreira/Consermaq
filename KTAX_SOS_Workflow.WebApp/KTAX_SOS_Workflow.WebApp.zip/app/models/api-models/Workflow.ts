﻿

/// <reference path="../../configs/_all.ts" />
module KTAX_SOS_Workflow {
    export class Workflow {
        public idControleAndamentoTarefa: number;
        public idGenerico: number;
        public idProcesso: number;
        public idTarefa: number;
        public strTitulo: string;
        public strTipoTarefaWorkFlow: string;
        public idSprintProjeto: number;
        public horas: string;

        constructor() {
        }
    }
} 