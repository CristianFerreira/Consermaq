

/// <reference path="../../configs/_all.ts" />
module KTAX_SOS_Workflow {
    export class SistemaContexto {
        
        public usuarioLogado: SosUsuario;

        constructor() {

        }
    }
} 