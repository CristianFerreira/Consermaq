

/// <reference path="../../configs/_all.ts" />
module KTAX_SOS_Workflow {
    export class HoraModel {
        
        public horas: number;
        public minutos: number;

        constructor(horaMinutos?: string) {
            this.horas = 0;
            this.minutos = 0;
            if(horaMinutos){
                this.horas = parseInt(horaMinutos.split(":")[0]);
                this.minutos = parseInt(horaMinutos.split(":")[1]);
            }
        }

        public toString(): string{
            var negativo = ((this.horas < 0) || (this.minutos < 0));

            var horas = (Math.abs(this.horas) < 10) ? "0" + Math.abs(this.horas) : Math.abs(this.horas);
            var minutos = (Math.abs(this.minutos) < 10) ? "0" + Math.abs(this.minutos) : Math.abs(this.minutos);
            
            return negativo ? "-" + (horas + ":" + minutos) : (horas + ":" + minutos);
        }
    }
} 