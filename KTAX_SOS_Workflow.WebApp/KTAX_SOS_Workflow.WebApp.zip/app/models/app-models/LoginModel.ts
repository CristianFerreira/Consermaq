

/// <reference path="../../configs/_all.ts" />
module KTAX_SOS_Workflow {
    export class LoginModel {
        public nomeUsuario: string;
        public senha: string;

        constructor(nomeUsuario?: string, senha?: string) {
            this.nomeUsuario = nomeUsuario;
            this.senha = senha;
        }
    }
} 