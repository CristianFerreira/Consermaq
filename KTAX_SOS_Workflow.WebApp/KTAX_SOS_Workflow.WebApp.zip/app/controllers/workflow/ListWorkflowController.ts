﻿

/// <reference path="../../configs/_all.ts" />

module KTAX_SOS_Workflow {
    export class ListWorkflowController {

        static $inject = ['$location', 'WorkflowService', '$uibModal', 'toastr'];

        public gridOptions: any;
        private $location: ILocationService;
        private workflowService: WorkflowService;
        public workflows: Array<Workflow>;
        private $uibModal: IModalService;
        public toastr: Toastr;

        constructor($location: ILocationService, 
                    workflowService: WorkflowService, 
                    $uibModal: IModalService, 
                    toastr: Toastr) {

            this.$location = $location;
            this.workflowService = workflowService;
            this.$uibModal = $uibModal;
            this.toastr = toastr;

            this.buildGridGraphics();
        }

        public buildGridGraphics() : void {
            this.gridOptions = {
                data: new Array<Workflow>(),
                columnDefs: [
                    {
                        field: 'idTarefa',
                        enableHiding: false,
                        displayName: "ID Tarefa"
                    },
                    {
                        field: 'strTitulo',
                        enableHiding: false,
                        displayName: "Título"
                    },
                    {
                        field: 'strTipoTarefaWorkFlow',
                        enableHiding: false,
                        displayName: "Tipo Workflow"
                    },
                    {
                        name: 'lancamentoHoras',
                        enableHiding: false,
                        headerCellTemplate: '<div class="ui-grid-top-panel" style="text-align: center;padding-top:5px;">Horas (Est/Rea/Falt)</div>',
                        cellTemplate: '<div class="text-center">'+ 
                                        '   <a class="btn primary"' +
                                        '        uib-tooltip="Click para lançar horas"' + 
                                        '        tooltip-placement="bottom-left"'+
                                        '        tooltip-trigger="\'mouseenter\'"'+
                                        '        tooltip-enable="true"'+
                                        '        ng-click="grid.appScope.vm.abrirModalLancamentoHoras(row.entity)">' +
                                        '       {{ row.entity.horas }}'+
                                        '   </a>'+
                                        '</div>'
                    },
                    {
                        name: 'actions',
                        enableHiding: false,
                        headerCellTemplate: '<div class="ui-grid-top-panel" style="text-align: center;padding-top:5px;">Ações</div>',
                        cellTemplate: '<div class="text-center">'+
                                        '   <a uib-tooltip="Click para próxima"' + 
                                        '        tooltip-placement="bottom-left"'+
                                        '        tooltip-trigger="\'mouseenter\'"'+
                                        '        tooltip-enable="true"'+
                                        '        ng-click="grid.appScope.vm.ExecutaControleAndamentoTarefa(row.entity)">' +
                                        '       <span class="glyphicon glyphicon-forward"></span>'+
                                        '   </a>'+
                                        '</div>'
                    }
                ],
                toggleRow: function(rowNum){
                    this.gridApi.treeBase.toggleRowTreeState(this.gridApi.grid.renderContainers.body.visibleRowCache[rowNum]);
                },
                toggleExpandNoChildren: function(){
                    this.gridOptions.showTreeExpandNoChildren = !this.gridOptions.showTreeExpandNoChildren;
                    this.gridApi.grid.refresh();
                },
                onRegisterApi: function(gridApi) {
                    this.gridApi = gridApi;
                },
                toggleRowSelection: function() {
                    this.gridApi.selection.clearSelectedRows();
                    
                }        
            };

            this.carregarWorkflows();
        }

        public carregarWorkflows(): void {
            this.workflowService.listAll()
                .then((data) => {
                    this.configuraWorkflowsGrid(data);
                    this.workflows = data;
                    console.log("Carregou os workflows");
                })
                .catch((response) => console.log("Não carregou os workflows, erro: " + response));
        }

        public configuraWorkflowsGrid(workflows: Array<Workflow>): void{
            if(workflows){
                this.gridOptions.data = workflows;
            }
        }

        public filtrarWorkflows(workflows: Array<Workflow>): any{
            this.configuraWorkflowsGrid(workflows);
            return this.gridOptions;
        }

        public abrirModalLancamentoHoras(workflow: Workflow): void{
            this.$uibModal.open({
                animation: true,
                templateUrl: 'app/views/workflow/modal-lancamento-horas.html',
                controller: 'ModalLancamentoHorasController',
                controllerAs: 'vm',
                size: 'md',
                resolve: {
                    workflow: ()=> workflow
                }
            }).result.then(retorno => {
                if(retorno)
                    this.carregarWorkflows();
            }, ()=> {

            });
        }

        public ExecutaControleAndamentoTarefa(workflow: Workflow){
            this.workflowService.executaControleAndamentoTarefa(workflow)
                .then((data) => {
                    this.carregarWorkflows();
                    this.toastr.success("Controle executado", "Sucesso");
                })
                .catch((response) => {
                    this.toastr.error("Controle não executado", "Erro");
                });
        }
    }
    angular.module(appConfig.appName).controller('ListWorkflowController', ListWorkflowController);
}