/// <reference path="_all.ts" />

module KTAX_SOS_Workflow {
    'use strict';

    var modules = new Array<string>();
    modules.push('ngRoute');
    modules.push('ngTouch');
    modules.push('ngAnimate');
    modules.push('ngMessages');
    modules.push('ui.bootstrap');
    modules.push('ui.grid');
    modules.push('ui.grid.pagination');
    modules.push('ui.grid.treeView');
    modules.push('ui.grid.selection');
    modules.push('ui.grid.autoResize');
    modules.push('ui.bootstrap.timepicker');
    modules.push('toastr');

    angular.module(appConfig.appName, modules);
}