/// <reference path="_all.ts" />

module KTAX_SOS_Workflow {
    'use strict';

    function config($routeProvider: ng.route.IRouteProvider) {
        $routeProvider
            .when("/", {
                templateUrl: "app/views/workflow/list-workflow.html",
                controller: "ListWorkflowController",
                controllerAs: "vm"
            })
            .when("/login", {
                templateUrl: "app/views/autenticacao/login.html",
                controller: "LoginController",
                controllerAs: "vm"
            })
            .when("/logout", {
                templateUrl: "app/views/autenticacao/login.html",
                controller: "LogoutController",
                controllerAs: "vm"
            })
            .otherwise({
                templateUrl: "app/views/shared/404.html",
                controller: "SharedController",
                controllerAs: "vm"
            });;
    }

    config.$inject = ['$routeProvider'];

    angular.module(appConfig.appName).config(config);
}