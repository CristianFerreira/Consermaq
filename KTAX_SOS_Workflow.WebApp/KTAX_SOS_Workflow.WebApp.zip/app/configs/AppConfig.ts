

var appConfig = {
    appName: "KTAX_SOS_Workflow",
    version: "0.0.1",
    auth_token: "ktax_sos_workflow_token",
    auth_sistema_contexto: "ktax_sos_workflow_user",
    testMode: false,
    defaultRoute: "/",
    rootServiceRoute: "http://localhost:41000/",
    serviceUrls: ()=> {
        return {
            autenticacao:{
                sistema: appConfig.rootServiceRoute + "api/security/token"
            },
            workflow: {
                listAll: appConfig.rootServiceRoute + "api/workflow/listarTodos",
                executaControleAndamentoTarefa: appConfig.rootServiceRoute + "api/workflow/ExecutaControleAndamentoTarefa",
            },
            sosTarefarealizado: {
                lancamentoDeHoras: appConfig.rootServiceRoute + "api/SosTarefarealizado/lancamentoDeHoras",
            }
        };
    }
};