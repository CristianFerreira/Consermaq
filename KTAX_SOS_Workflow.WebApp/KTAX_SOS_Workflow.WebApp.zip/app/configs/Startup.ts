/// <reference path="_all.ts" />

module KTAX_SOS_Workflow {
    'use strict';

    function config() {
        
    }
    
    function start($rootScope: IRootScope, autenticacaoService: AutenticacaoService) {
        
        autenticacaoService.carregaUsuarioAutenticado();
    }

    
	angular.module(appConfig.appName).config(config);
    
	start.$inject = ['$rootScope', 'AutenticacaoService'];
	angular.module(appConfig.appName).run(start);
}